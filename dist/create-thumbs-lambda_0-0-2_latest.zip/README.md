# create-thumbnails-lambda
This project shows how to use the [grunt-aws-lambda](https://www.npmjs.com/package/grunt-aws-lambda) plugin to develop and test your AWS Lambda function locally. It uses the CreateThumbnail function described in the [AWS Lambda documentation](http://docs.aws.amazon.com/lambda/latest/dg/walkthrough-s3-events-adminuser.html).
